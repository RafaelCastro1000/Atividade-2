from django.apps import AppConfig


class ApprafaelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppRafael'
